﻿1.入口：board_fsm4_main.c:main
2.串口打印使用 trace_printf usart3
3.需要添加的代码，标记： # error "Not Implemented!"
4.适用于MDK环境，项目文件： exp_example\MDK-ARM\exp_example.uvprojx
